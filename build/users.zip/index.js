exports.handler = async (event) => {
    console.log('Event:', JSON.stringify(event, null, 2));

    // Mock users data - in real implementation, you'd fetch from DynamoDB
    const users = [
        {
            id: '1',
            name: 'John Doe',
            email: 'john@example.com',
            createdAt: '2024-01-15T10:30:00Z'
        },
        {
            id: '2',
            name: 'Jane Smith',
            email: 'jane@example.com',
            createdAt: '2024-01-16T14:45:00Z'
        }
    ];

    const response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        body: JSON.stringify({
            users: users,
            count: users.length,
            timestamp: new Date().toISOString()
        })
    };

    return response;
};