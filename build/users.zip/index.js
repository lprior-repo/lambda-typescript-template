"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const logger_1 = require("@aws-lambda-powertools/logger");
const tracer_1 = require("@aws-lambda-powertools/tracer");
const metrics_1 = require("@aws-lambda-powertools/metrics");
const logger = new logger_1.Logger({
    serviceName: 'users-service',
    environment: process.env.ENVIRONMENT || 'dev',
    logLevel: 'INFO'
});
const tracer = new tracer_1.Tracer({
    serviceName: 'users-service',
    captureHTTPsRequests: true
});
const metrics = new metrics_1.Metrics({
    namespace: 'LambdaTemplate/Users',
    serviceName: 'users-service',
    defaultDimensions: {
        environment: process.env.ENVIRONMENT || 'dev'
    }
});
const addCustomMetrics = (userCount, success) => {
    metrics.addMetric('RequestCount', metrics_1.MetricUnit.Count, 1);
    metrics.addMetric('UserCount', metrics_1.MetricUnit.Count, userCount);
    if (success) {
        metrics.addMetric('SuccessCount', metrics_1.MetricUnit.Count, 1);
    }
    else {
        metrics.addMetric('ErrorCount', metrics_1.MetricUnit.Count, 1);
    }
};
const getUsersFromDatabase = async () => {
    const users = [
        {
            id: '1',
            name: 'John Doe',
            email: 'john@example.com',
            createdAt: '2024-01-15T10:30:00Z'
        },
        {
            id: '2',
            name: 'Jane Smith',
            email: 'jane@example.com',
            createdAt: '2024-01-16T14:45:00Z'
        },
        {
            id: '3',
            name: 'Alice Johnson',
            email: 'alice@example.com',
            createdAt: '2024-01-17T09:15:00Z'
        }
    ];
    await new Promise(resolve => setTimeout(resolve, 50));
    logger.info('Users retrieved from database', { userCount: users.length });
    tracer.putAnnotation('userCount', users.length);
    return users;
};
const processUsersRequest = async (event) => {
    tracer.putAnnotation('path', event.path || '/users');
    tracer.putMetadata('event', event);
    logger.info('Processing users request', {
        path: event.path,
        httpMethod: event.httpMethod,
        userAgent: event.headers?.['User-Agent']
    });
    const users = await getUsersFromDatabase();
    const response = {
        users,
        count: users.length,
        timestamp: new Date().toISOString(),
        requestId: event.requestContext?.requestId || 'unknown'
    };
    logger.info('Users request processed successfully', {
        userCount: users.length,
        requestId: response.requestId
    });
    return response;
};
const handler = async (event, context) => {
    tracer.putAnnotation('correlationId', context.awsRequestId);
    logger.addContext(context);
    try {
        logger.info('Lambda invocation started', {
            requestId: context.awsRequestId,
            functionName: context.functionName,
            functionVersion: context.functionVersion
        });
        const responseData = await processUsersRequest(event);
        addCustomMetrics(responseData.count, true);
        const response = {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                'X-Request-ID': context.awsRequestId,
                'Cache-Control': 'max-age=300'
            },
            body: JSON.stringify(responseData, null, 2)
        };
        logger.info('Lambda invocation completed successfully');
        return response;
    }
    catch (error) {
        logger.error('Lambda invocation failed', {
            error: error instanceof Error ? error.message : 'Unknown error',
            stack: error instanceof Error ? error.stack : undefined
        });
        addCustomMetrics(0, false);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'X-Request-ID': context.awsRequestId
            },
            body: JSON.stringify({
                message: 'Internal server error',
                requestId: context.awsRequestId,
                timestamp: new Date().toISOString()
            })
        };
    }
    finally {
        metrics.publishStoredMetrics();
    }
};
exports.handler = handler;
//# sourceMappingURL=index.js.map