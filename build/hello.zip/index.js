"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const logger_1 = require("@aws-lambda-powertools/logger");
const tracer_1 = require("@aws-lambda-powertools/tracer");
const metrics_1 = require("@aws-lambda-powertools/metrics");
const logger = new logger_1.Logger({
    serviceName: 'hello-service',
    environment: process.env.ENVIRONMENT || 'dev',
    logLevel: 'INFO'
});
const tracer = new tracer_1.Tracer({
    serviceName: 'hello-service',
    captureHTTPsRequests: true
});
const metrics = new metrics_1.Metrics({
    namespace: 'LambdaTemplate/Hello',
    serviceName: 'hello-service',
    defaultDimensions: {
        environment: process.env.ENVIRONMENT || 'dev'
    }
});
const addCustomMetrics = (success) => {
    metrics.addMetric('RequestCount', metrics_1.MetricUnit.Count, 1);
    if (success) {
        metrics.addMetric('SuccessCount', metrics_1.MetricUnit.Count, 1);
    }
    else {
        metrics.addMetric('ErrorCount', metrics_1.MetricUnit.Count, 1);
    }
};
const processRequest = async (event) => {
    tracer.putAnnotation('path', event.path || '/hello');
    tracer.putMetadata('event', event);
    logger.info('Processing hello request', {
        path: event.path,
        httpMethod: event.httpMethod,
        userAgent: event.headers?.['User-Agent']
    });
    const appVersion = 'v1.0.0';
    const response = {
        message: 'Hello from TypeScript Lambda with Powertools!',
        path: event.path || '/hello',
        timestamp: new Date().toISOString(),
        requestId: event.requestContext?.requestId || 'unknown',
        version: appVersion
    };
    logger.info('Hello request processed successfully', { response });
    return response;
};
const handler = async (event, context) => {
    const correlationId = context.awsRequestId;
    tracer.putAnnotation('correlationId', correlationId);
    tracer.putAnnotation('requestId', context.awsRequestId);
    tracer.putAnnotation('traceId', process.env._X_AMZN_TRACE_ID || '');
    try {
        logger.info('Lambda invocation started', {
            correlationId,
            requestId: context.awsRequestId,
            functionName: context.functionName,
            functionVersion: context.functionVersion,
            remainingTimeMs: context.getRemainingTimeInMillis(),
            traceId: process.env._X_AMZN_TRACE_ID
        });
        const responseData = await processRequest(event);
        addCustomMetrics(true);
        const response = {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                'X-Request-ID': context.awsRequestId,
                'X-Trace-ID': process.env._X_AMZN_TRACE_ID || '',
                'X-Correlation-ID': correlationId
            },
            body: JSON.stringify(responseData, null, 2)
        };
        logger.info('Lambda invocation completed successfully', {
            correlationId,
            statusCode: response.statusCode,
            responseSize: response.body.length
        });
        return response;
    }
    catch (error) {
        logger.error('Lambda invocation failed', {
            correlationId,
            error: error instanceof Error ? error.message : 'Unknown error',
            stack: error instanceof Error ? error.stack : undefined
        });
        addCustomMetrics(false);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'X-Request-ID': context.awsRequestId,
                'X-Trace-ID': process.env._X_AMZN_TRACE_ID || '',
                'X-Correlation-ID': correlationId
            },
            body: JSON.stringify({
                message: 'Internal server error',
                requestId: context.awsRequestId,
                correlationId,
                timestamp: new Date().toISOString()
            })
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=index.js.map